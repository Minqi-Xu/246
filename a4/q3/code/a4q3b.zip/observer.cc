#include "observer.h"

Observer<InfoType, StateType>::~Observer() {}
